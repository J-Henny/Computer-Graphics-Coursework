****
*  **Class**     :  CSCI 4565 Spring 2022
*  **Name        : Jack Hurd**
*  **ID          : 108753577**                                 
*  **Homework#**       :  4                
*  **Due Date**  :  Apr 20, 2022
****
# Read Me

## Description of the program 

This program handles antialiasing and cube environment mapping in OpenGL.

It uses swing/elevation UI from HW2, and allows user to change shape, mapping style, and images.

Besides this README file, it includes the MS Visual Studio Project Solution, and Homework4.cpp


##  Source files
- ***Homework4.cpp***
 This is the source file with all glut main loop functionalities implemented.
   
##  Circumstances of programs

The program runs successfully.  

The program was developed and tested via MS Visual Studios, with x64 hardware builds.

## How to build and run the program

** 1. Unzip the zip file in a linux command line.**  The files are all within one directory.  
   

   Type ls to view the files:
   ```
   % ls
   ```

   You should see the following files:
   ```
        Homework4.cpp
        Homework4 Folder
        README.md (this file)
   ```
** 2. Build the program.**

    Open:
    % Homework4.sln

** 3. Run the program by: **
   `Clicking run in the MS Visual Studio GUI.`
