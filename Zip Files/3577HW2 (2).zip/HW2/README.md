****
*  **Class**     :  CSCI 4565 Spring 2022
*  **Name        : Jack Hurd**
*  **ID          : 108753577**                                 
*  **Homework#**       :  2                
*  **Due Date**  :  Mar 2, 2022
****
# Read Me

## Description of the program 

This program handles viewing and modeling transformations using the openGL package in C.

It displays a teapot, with a grid toggle option, and shows the multiple viewpoints from the teapot by dragging the mouse.

Besides this README file, it includes the MS Visual Studio Project Solution, and Homework2.c


##  Source files
- ***Homework2.c***
 This is the source file with all glut main loop functionalities implemented.
   
##  Circumstances of programs

The program runs successfully.  

The program was developed and tested via MS Visual Studios, with x64 hardware builds.

## How to build and run the program

** 1. Unzip the zip file in a linux command line.**  The files are all within one directory.  
   

   Type ls to view the files:
   ```
   % ls
   ```

   You should see the following files:
   ```
        Homework2.c
        Homework2.sln
        README.md (this file)
   ```
** 2. Build the program.**

    Open:
    % Homework2.sln

** 3. Run the program by: **
   `Clicking run in the MS Visual Studio GUI.`
