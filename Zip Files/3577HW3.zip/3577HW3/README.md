****
*  **Class**     :  CSCI 4565 Spring 2022
*  **Name        : Jack Hurd**
*  **ID          : 108753577**                                 
*  **Homework#**       :  3                
*  **Due Date**  :  Mar 22, 2022
****
# Read Me

## Description of the program 

This program handles subdivision of polygons using an isocahedron in OpenGL.

It uses swing/elevation UI from HW2, toggles lights, and allows the user to select the subdivisions of polygons.

Besides this README file, it includes the MS Visual Studio Project Solution, and Homework3.cpp


##  Source files
- ***Homework3.cpp***
 This is the source file with all glut main loop functionalities implemented.
   
##  Circumstances of programs

The program runs successfully.  

The program was developed and tested via MS Visual Studios, with x64 hardware builds.

## How to build and run the program

** 1. Unzip the zip file in a linux command line.**  The files are all within one directory.  
   

   Type ls to view the files:
   ```
   % ls
   ```

   You should see the following files:
   ```
        Homework3.cpp
        Homework3 Folder
        README.md (this file)
   ```
** 2. Build the program.**

    Open:
    % Homework3.sln

** 3. Run the program by: **
   `Clicking run in the MS Visual Studio GUI.`
